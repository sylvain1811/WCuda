
#pragma once

#include "cpptest.h"
#include <string>

using std::string;

bool runTestConsole(string titre, Test::Suite& test);
bool runTestHtml(string titre, Test::Suite& test);



/*----------------------------------------------------------------------*\
 |*			End	 					*|
 \*---------------------------------------------------------------------*/

