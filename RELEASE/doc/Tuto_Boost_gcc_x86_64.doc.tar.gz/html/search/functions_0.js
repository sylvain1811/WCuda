var searchData=
[
  ['getinstance',['getInstance',['../df/d56/classSingletonBoost.html#a88e30bf50f6b3ea13b1ce6887d9c3191',1,'SingletonBoost::getInstance()'],['../d3/d75/classSingletonStd.html#a464334850880abc916642a63dc26e02e',1,'SingletonStd::getInstance()']]],
  ['getresult',['getResult',['../df/d77/classRunnable.html#a41f086782f522dc7cf057e7869b0de2b',1,'Runnable::getResult()'],['../d0/d5f/classRunnable__SDT.html#a4d62e3823d61fcb0631ab04caaafa90c',1,'Runnable_SDT::getResult()']]]
];
