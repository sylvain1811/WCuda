var searchData=
[
  ['gethuestart',['getHueStart',['../de/d9d/classSphere.html#a2fc9bdc8c14d936e7bf247a4b0ad69e9',1,'Sphere']]],
  ['gettabsphere',['getTabSphere',['../db/dc4/classSphereCreator.html#a8fa011fdd03e73d38d56c24ab903910e',1,'SphereCreator']]]
];
