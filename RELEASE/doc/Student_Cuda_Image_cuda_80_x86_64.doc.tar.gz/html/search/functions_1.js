var searchData=
[
  ['barivox',['barivox',['../de/d9b/mainBarivox_8cpp.html#a76cdc5831a85fd7504c8e0b70df95eea',1,'mainBarivox.cpp']]],
  ['brightness',['brightness',['../de/d9d/classSphere.html#ab06d516b8287c95132f78c928a472b48',1,'Sphere']]],
  ['bruteforce',['bruteForce',['../d9/df2/mainBruteForce_8cpp.html#a8b8f131dba5a9af7a21d78980dd08522',1,'mainBruteForce.cpp']]]
];
