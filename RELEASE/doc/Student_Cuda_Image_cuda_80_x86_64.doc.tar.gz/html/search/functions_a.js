var searchData=
[
  ['sphere',['Sphere',['../de/d9d/classSphere.html#a4a5b2a62d7d78f4dc05e672909ba0e0c',1,'Sphere::Sphere(float3 centre, float rayon, float hueStart)'],['../de/d9d/classSphere.html#aa64ffdac9a51b6cbd1bd796d3d5cada9',1,'Sphere::Sphere()']]],
  ['spherecreator',['SphereCreator',['../db/dc4/classSphereCreator.html#a20253bd67a6c8311d9e5068c28f94bfd',1,'SphereCreator']]]
];
