var searchData=
[
  ['distance',['distance',['../de/d9d/classSphere.html#a8fc95d8f38c9b3915d86e126e8aa6dfc',1,'Sphere']]],
  ['dz',['dz',['../de/d9d/classSphere.html#ac96d2b3246ab71f21392e0b12ce7beeb',1,'Sphere']]]
];
