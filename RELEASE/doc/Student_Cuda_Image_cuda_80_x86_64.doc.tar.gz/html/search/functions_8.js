var searchData=
[
  ['process',['process',['../d7/dea/classRippling.html#a20a0af4e1f24bc1cf8c52b95b86df194',1,'Rippling::process()'],['../df/d6e/classMandelbrot.html#ab4c21a5278a3bec8936ac1313a9fb22b',1,'Mandelbrot::process()'],['../d7/de7/classRaytracing.html#affd196f2e804df031dabfa81e1b2086b',1,'Raytracing::process()']]]
];
