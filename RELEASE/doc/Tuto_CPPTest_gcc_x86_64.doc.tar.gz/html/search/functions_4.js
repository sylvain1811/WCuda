var searchData=
[
  ['sum',['sum',['../d5/d6b/scalar_8cpp.html#a6ab0b35ab6e4b1f0e6cbac41aa8dd021',1,'sum(double x1, double x2):&#160;scalar.cpp'],['../db/d94/scalar_8h.html#a6ab0b35ab6e4b1f0e6cbac41aa8dd021',1,'sum(double x1, double x2):&#160;scalar.cpp']]]
];
