var searchData=
[
  ['plus',['plus',['../db/d7c/integer_8cpp.html#ac75d31118e0e0fcb392f121c40bc95e5',1,'plus(int x1, int x2):&#160;integer.cpp'],['../d6/d3d/integer_8h.html#ac75d31118e0e0fcb392f121c40bc95e5',1,'plus(int x1, int x2):&#160;integer.cpp']]]
];
