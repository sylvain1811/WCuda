var searchData=
[
  ['processentrelacementomp',['processEntrelacementOMP',['../d7/dea/classRippling.html#a5e3f34781fbd1656cb31e2db343c2dba',1,'Rippling::processEntrelacementOMP()'],['../df/d6e/classMandelbrot.html#a136f0f08b5c29844d0774750b244e137',1,'Mandelbrot::processEntrelacementOMP()']]],
  ['processforautoomp',['processForAutoOMP',['../d7/dea/classRippling.html#aa6c50a6189fdaa21b2be1ad1b4a985c1',1,'Rippling::processForAutoOMP()'],['../df/d6e/classMandelbrot.html#a876934e3429b64adb1ec2fe8996bbbde',1,'Mandelbrot::processForAutoOMP()']]]
];
