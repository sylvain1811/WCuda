var searchData=
[
  ['quadratique',['Quadratique',['../df/d7f/classQuadratique.html#a61c1cc38bc00874851a381f4912548e4',1,'Quadratique::Quadratique(double a, double b, double c)'],['../df/d7f/classQuadratique.html#ad2dd682674ca6c295932b286d1d6cafc',1,'Quadratique::Quadratique(ABC abc)']]]
];
