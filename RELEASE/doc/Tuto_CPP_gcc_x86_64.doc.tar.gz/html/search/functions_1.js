var searchData=
[
  ['gettabx',['getTabX',['../df/d7f/classQuadratique.html#a551e4203c92cd38e21c4aa51e6048fd0',1,'Quadratique']]]
];
