var searchData=
[
  ['phi',['phi',['../d2/da0/classAlgo.html#a717d314735d5cb02d9239022be079385',1,'Algo']]]
];
