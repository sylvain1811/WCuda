var searchData=
[
  ['fpi',['fpi',['../d7/d1b/00__pi__tools_8cpp.html#ac890d41c96e46c5a6e7ae4d9846d112e',1,'fpi(double x):&#160;00_pi_tools.cpp'],['../d6/da3/00__pi__tools_8h.html#ac890d41c96e46c5a6e7ae4d9846d112e',1,'fpi(double x):&#160;00_pi_tools.cpp']]]
];
