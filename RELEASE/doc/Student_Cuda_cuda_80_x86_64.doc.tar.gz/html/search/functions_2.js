var searchData=
[
  ['getn0',['getN0',['../d3/d96/classMontecarlo.html#aedc217fbeb0a94818b06ef855882fbea',1,'Montecarlo']]],
  ['getpi',['getPi',['../db/d40/classSlice.html#a66b79805f48cc1e56b50a8f22c0091fc',1,'Slice::getPi()'],['../d0/d58/classSliceAd.html#ac28d5c64ae43897b8b73886b06f30f93',1,'SliceAd::getPi()'],['../d3/d96/classMontecarlo.html#aa0dc71cdf32a9c4d9a5e1e43a98d4e3c',1,'Montecarlo::getPi()'],['../df/d9f/classMontecarloMultiGPU.html#a84df49b7bd623f00726d5da3c373f675',1,'MontecarloMultiGPU::getPi()']]]
];
